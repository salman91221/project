import React, { useState } from 'react'
import { Button, Input, TextField, Typography } from '@mui/material'
import { Link, useNavigate } from 'react-router-dom'
import axios from "axios"

const Adlogin = () => {

 const [ademail, setEmail] = useState('')
 const [adpassword, setPassword] = useState('')

 const history = useNavigate();


 const handleSubmit = (e) => {
   e.preventDefault()
   axios.post('http://localhost:3008/adlogin', {ademail, adpassword})
   .then(res => {console.log(res)
     if(res.data === "exist") {
         history('/admin')
          
     }
    
 
   })
   .catch(err=> console.log(err))
 }

  return (
    <div >
      <div style={{ paddingTop: '90px' }}></div>
      <div className='sign-up-container'>
      <div >
       <form className='sign-up-form'
        onSubmit={handleSubmit} action='post' >
          <Typography variant="h5" color={'error'}>
            <b>Admin Login </b>
          </Typography><br></br><br></br>

          <label>Admin ID:</label>
          <input type='text' onChange={(e) => { setEmail(e.target.value) }} placeholder='Admin Id' />


          <label>Password:</label>
          <input type='password' onChange={(e) => { setPassword(e.target.value) }} placeholder='****' />
          <button className='signup-button' type='submit' onClick={handleSubmit}
          >Login </button><br></br>
           <Button >
            <Link to={'/signin'} style={{ textDecoration: 'none', color: 'brown' }}>
              User SignUp
            </Link>
          </Button>
        
        </form>
</div>
      </div></div>
  )
}

export default Adlogin