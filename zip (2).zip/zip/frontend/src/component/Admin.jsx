import React from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@mui/material'

const Admin = () => {
  return (
    <div>
   <Button >
            <Link to={'/adviewdnr'} style={{ textDecoration: 'none', color: 'brown' }}>
         Donar List
            </Link>
          </Button>

          <Button >
            <Link to={'/adreq'} style={{ textDecoration: 'none', color: 'brown' }}>
           Request List
            </Link>
          </Button>
    </div>
  )
}

export default Admin
