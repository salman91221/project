import { AppBar, Box, Button, Toolbar, Typography } from "@mui/material";
import React from "react";
import { Link } from "react-router-dom";
import Avatar from '@mui/material/Avatar';

const Navbar = () => {
  return (
    <div>
      <Box>

        <AppBar  color="secondary">
          <Toolbar>
          <Avatar alt="" src="https://s.tmimgcdn.com/scr/1200x750/308700/blood-donors-icon--blood-logo-vector-illustration-v1_308715-original.jpg" />
            
            <br /><br /><br /><Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
              MyApp
            </Typography>
            <Button>
              <Link to={"/"} style={{ textDecoration: "none", color: "white" }}>
                Home
              
              </Link>
            </Button>
           
            <Button ><Link to ={'/login'} style={{ textDecoration: "none", color: "white" } }>login </Link> </Button>
        <Button ><Link to ={'/signin'} style={{ textDecoration: "none", color: "white" }}>sign up </Link> </Button>
          </Toolbar>
        </AppBar>
      </Box>
    </div>
  );
};

export default Navbar;
