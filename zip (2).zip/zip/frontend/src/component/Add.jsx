import { Button, FormControl, InputLabel, MenuItem, NativeSelect, Select, TextField, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
const Add = (props) => {
  var [inputs, setInputs] = useState({ rname: "",rage:"", rbloodgroup: "", remail: "", rmobile: "" });
  var location = useLocation();
  var history = useNavigate()
  console.log("loc", location.state);

  const inputHandler = (e) => {
    setInputs({ ...inputs, [e.target.name]: e.target.value });
    console.log(inputs);
  };

  const addHandler = () => {
    console.log("clicked");
    if (location.state !== null) {
      axios
        .put("http://localhost:3008/edit/"+location.state.val._id,inputs)
        .then((res) => {
            // alert(res.data.message)
            history('/dashboard')
            
        })
        .catch((err) => console.log(err));
    }else{
        axios
        .post("http://localhost:3008/requestadd", inputs)
        .then((res) => {
          console.log(res);
          // alert(res.data.message);
          history('/dashboard')
        })
        .catch((err) => {
          console.log(err);
        });
    }
  };

  useEffect(() => {
    if (location.state !== null) {
      setInputs({
        ...inputs,
        rname: location.state.val.rname,
       rbloodgroup : location.state.val.rbloodgroup,
        remail: location.state.val.remail,
        rmobile: location.state.val.rmobile,
      });
    }
  }, []);


//   const [age, setAge] = React.useState('');


  return (
    
    <div style={{ marginTop: "3%", textAlign: "center" }} >

<div className="sign-up-container">
      <form className="sign-up-form">
      <Typography  color={'error'}><b><h4>Donate form</h4></b></Typography>
 <label htmlFor='name'>Name:</label>
<input type='text' onChange={inputHandler} label="name" name='rname' value={inputs.rname}/>



<label htmlFor='name'>Age:</label>
<input type='age' onChange={inputHandler} label="age" name='rage' value={inputs.rage}/>

     
       <label htmlFor='text'>Bloodgroup</label>
<input type='text' onChange={inputHandler} label="bloodgroup" name='rbloodgroup' value={inputs.rbloodgroup}/>








<label htmlFor='email'>Email:</label>
<input type='email' onChange={inputHandler} label="email" name='remail' value={inputs.remail}/><br/>

     
     

<label htmlFor='number'>Mobile</label>
<input type='text' onChange={inputHandler} label="Mobile" name='rmobile' value={inputs.rmobile}/>


      
      <Button className="signup-button " color="error"  variant="contained"  onClick={addHandler}>
        Submit
      </Button>
      {/* <Button variant="contained" color="brown" onClick={addHandler}>Submit</Button> */}
      </form>
      </div>
    </div>
  );
};

export default Add;