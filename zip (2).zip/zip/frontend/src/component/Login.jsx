import React, { useState } from 'react'
import { Button, Input, TextField, Typography } from '@mui/material'
import { Link, useNavigate } from 'react-router-dom'
import axios from "axios"
import './style.css'


function Login  ()  {

 
  // const [username, setUsername] = useState('');
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const history = useNavigate();
  // async function submit(e) {
  //   e.preventDefault();

  //   try {
  //     await axios.post('http://localhost:3005/login', {
  //       email, password
  //     })
  //       .then(res => {
  //         if (res.data = 'exist') {
  //           history('/dashboard', { state: { id: email } })
  //         }
          // else if (res.data = 'notexist') {
          //   alert('User have not sign up')
          // }
  //       })
  //       .catch(e => {
  //         alert('wrong details')
  //         console.log(e);
  //       })


  //   }
  //   catch (e) {
  //     console.log(e)
  //   }
  // }

  const handleSubmit = (e) => {
    e.preventDefault()
    axios.post('http://localhost:3008/login', {email, password})
    .then(res => {console.log(res)
      if(res.data === "exist") {
          history('/userdash')
           
      }
     
    //  else if (res.data = 'notexist') {
    //   alert('User have not sign up')
    // }
    })
    .catch(err=> console.log(err))
  }



  return (
  
      <div style={{ paddingTop: '90px' }}>
        <div className='sign-up-container'>
        <form className='sign-up-form'
      onSubmit={handleSubmit} action='post'>
        <Typography variant="h5" color={'error'}>
          <b> Login </b>
        </Typography><br></br><br></br>

        <label htmlFor='email'>Email:</label>
        <input type='email' onChange={(e) => { setEmail(e.target.value) } } placeholder='Email' />


        <label htmlFor='password'>Password:</label>
        <input type='password' onChange={(e) => { setPassword(e.target.value) } } placeholder='****' />


        <button className='signup-button' type='submit' onClick={handleSubmit}
        >Login </button><br></br>
        <Button>
          <Link to={'/signin'} style={{ textDecoration: 'none', color: 'brown' }}>
            SignUp
          </Link>
        </Button>
       
        <Button>
          <Link to={'/adlogin'} style={{ textDecoration: 'none', color: 'brown' }}>
            admin Login
          </Link>
        </Button>
      </form>

    </div>
    </div>
  )
}

export default Login