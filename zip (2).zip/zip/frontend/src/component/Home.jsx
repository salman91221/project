import React from 'react'
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { Link } from 'react-router-dom';


const Home = () => {
  return (
    <div><br /><br /><br />
        <center>
      <Card sx={{ maxWidth: 345 }}>
      <CardMedia
        sx={{ height: 300}}
        image="https://images.onlymyhealth.com/imported/images/2024/June/14_Jun_2024/mn-donor.jpg"
        title="green iguana"
      />
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          BLOOD DONATION
        </Typography>
        <Typography variant="body2" color="text.secondary">
        You agree to have blood drawn so that it can be given to someone who needs a blood transfusion. Millions of people need blood transfusions each year. Some may need blood during surgery
        . Others depend on it after an accident or because they have a disease that requires certain parts of blood
        </Typography>
      </CardContent>
      <CardActions>
       
      </CardActions>
    </Card>
    </center>
    </div>
  )
}

export default Home
