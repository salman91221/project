
import { Button, TextField, Typography } from '@mui/material'
import React from 'react'
import { Link, useNavigate } from 'react-router-dom';

import { useState } from 'react';
import axios from 'axios';
import './style.css'



function Signin  ()  {

  const [name, setUsername] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
 


  const history = useNavigate()

  const handleSubmit = (e) => {
    e.preventDefault()
    axios.post('http://localhost:3008/signin', { name, email, password })
    .then(res => {
      console.log(res)
history('/login')
    }).catch(err => {
      console.log(err)
    })
  }








  return (

    <div style={{ paddingTop: '90px' }}>
    <div className='sign-up-container'>
      <form className='sign-up-form'
       onSubmit={handleSubmit}
      >

        <Typography variant="h5" color={'error'}>
          <b> SignUp Page</b>
        </Typography><br></br><br></br>


        <label htmlFor='username'>Name:</label>
        <input type='text' placeholder='Name' onChange={(e) => setUsername(e.target.value)} />


        <label htmlFor='email'>Email:</label>
        <input type='email' placeholder='Email' onChange={(e) => setEmail(e.target.value)} />



        <label htmlFor='password'>Password:</label>
        <input type='password' placeholder='****' onChange={(e) => setPassword(e.target.value)} />



        <button className='signup-button' type='submit' 
        // onClick={submit}
        >Sign Up</button>
        <p>Hava an Account?</p>
        <center> <Button >
          <Link to={'/login'} style={{ textDecoration: 'none', color: 'brown' }}>
            Login
          </Link>
        </Button></center>
      </form>
    </div>
    </div>
  )
}

export default Signin