import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

import Navbar from './component/Navbar'
import { Route, Routes } from 'react-router-dom'
import AdViewDnr from './component/AdViewDnr'
import Add from './component/Add'
import Home from './component/Home'
import Login from './component/Login'
import Signin from './component/Signin'
import Userdash from './component/Userdash'
import Req from './component/Req'
import Reqq from './component/Reqq'
import Admin from './component/Admin'
import Adlogin from './component/Adlogin'
import Asign from './component/Asign'
import Adreq from './component/Adreq'


import Adrequp from './component/Adrequp'
import Addnrup from './component/Addnrup'







function App() {
  const [count, setCount] = useState(0)

  return (
    <>
     <Navbar/> 
     <Routes>
      <Route path='/adviewdnr' element={<AdViewDnr/>}/>
      <Route path='/a' element={<Add/>}/>
      <Route path='/' element={<Home/>}/>
      <Route path='/login' element={<Login/>}/>
      <Route path='/signin' element={<Signin/>}/>
      <Route path='/userdash' element={<Userdash/>}/>
      <Route path='/req' element={<Req/>}/>
      <Route path='/reqq' element={<Reqq/>}/>
      <Route path='/admin' element={<Admin/>}/>
      <Route path='/adlogin' element={<Adlogin/>}/>
     <Route path='/adreg' element={<Asign/>}/>
     <Route path='/adreq' element={<Adreq/>}/>
     <Route path='/adrequp' element={<Adrequp/>}/>
     <Route path='/addnrup' element={<Addnrup/>}/>


     </Routes>
    </>
  )
}

export default App
