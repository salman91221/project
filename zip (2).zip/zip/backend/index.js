
const express = require('express')
var cors = require("cors");
require("./connection");
var empModel = require("./model/student");
var signModel = require("./model/signup.js");
var AdModel = require("./model/admin.js");
var DModel = require("./model/donor.js");



const app = new express()

// midd
app.use(express.json());
app.use(cors());
// api to add
app.post("/adddnr", async (req, res) => {
  try {
    await DModel(req.body).save();
    res.send({ message: "Data added!!" });
  } catch (error) {
    console.log(error);
  }
});

app.post("/addreq", async (req, res) => {
  try {
    await empModel(req.body).save();
    res.send({ message: "Data added!!" });
  } catch (error) {
    console.log(error);
  }
});

// api to view
app.get("/adviewreq", async (req, res) => {
  try {
    var data = await empModel.find();
    res.send(data);
  } catch (error) {
    console.log(error);
  }
});

// to delete dnr
app.delete("/removednr/:id", async (req, res) => {
    try {
       await DModel.findByIdAndDelete(req.params.id)
       res.send({message:"Deleted successfully!!!"})
    } catch (error) {
        console.log(error)
    }
});

// to delete req
app.delete("/removereq/:id", async (req, res) => {
  try {
     await empModel.findByIdAndDelete(req.params.id)
     res.send({message:"Deleted successfully!!!"})
  } catch (error) {
      console.log(error)
  }
});



// to update Donar List
app.put("/editdnr/:id", async (req, res) => {
    try {
      var data = await DModel.findByIdAndUpdate(req.params.id, req.body);
      res.send({message:'updated successfully',data})
    } catch (error) {
      console.log(error)
    }
  });


// to update Request List
app.put("/editreq/:id", async (req, res) => {
  try {
    var data = await empModel.findByIdAndUpdate(req.params.id, req.body);
    res.send({message:'updated successfully',data})
  } catch (error) {
    console.log(error)
  }
});

app.listen(3008, () => {
  
  console.log("port is up");
});

//sign yp


app.post('/signin', (req, res) => {
  signModel.create(req.body)
  .then(user => res.json(user))
  .catch(err => res.json(err))

})

// admin view Dnr
app.get("/adviewdnr", async (req, res) => {
  try {
    var data = await DModel.find();
    res.send(data);
  } catch (error) {
    console.log(error);
  }
});

//user login


app.post("/login", (req, res) => {
    const {email, password} = req.body;
    signModel.findOne({email: email})
    .then(user => {
        if(user) {
            if(user.password === password) {
                res.json("exist")
                
            } else {
                res.json("the password is incorrect")

            }
        } else {
            res.json("No record existed")
        }
    })
})


//sign yp


app.post('/adreg', (req, res) => {
  AdModel.create(req.body)
  .then(admin => res.json(admin))
  .catch(err => res.json(err))

})



//admin login


app.post("/adlogin", (req, res) => {
  const {ademail, adpassword} = req.body;
  AdModel.findOne({ademail: ademail})
  .then(admin => {
      if(admin) {
          if(admin.adpassword === adpassword) {
              res.json("exist")
              
          } else {
              res.json("the password is incorrect")

          }
      } else {
          res.json("No record existed")
      }
  })
})