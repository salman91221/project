var mongoose = require('mongoose');
var schema = mongoose.Schema({
    dname:String,
    dage:String,
    dblood:String,
    demail:String,
   dmobile:String, 
   rname:String,
   rage:String,
   rblood:String,
   remail:String,
  rmobile:String

})
 var EmployeeModel = mongoose.model("user",schema);
 module.exports=EmployeeModel;
