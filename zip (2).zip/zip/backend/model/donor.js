var mongoose = require('mongoose');
var schema = mongoose.Schema({
    dname:String,
    dage:String,
    dblood:String,
    demail:String,
   dmobile:String, 


})
 var DonorModel = mongoose.model("dnr",schema);
 module.exports=DonorModel;