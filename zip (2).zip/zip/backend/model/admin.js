var mongoose = require('mongoose');
var schema = mongoose.Schema({

    ademail:String,
    adpassword:String,
})
 var adminModel= mongoose.model("admin",schema);
 module.exports=adminModel;